This is a repository for a python rest api library for interfacing with shopify... Still under development
